// Automatischer Test: startet den Server, simuliert Geschenke und speichert Screenshots in ./screenshots
// Benötigt: npm i -D playwright-core  und einen installierten Chrome/Chromium (CHROME_PATH setzen falls nötig)
import { spawn } from 'node:child_process';
import { chromium } from 'playwright-core';
import fs from 'node:fs';

const PORT = 8091;
const CHROME = process.env.CHROME_PATH || ['/usr/bin/google-chrome', '/usr/bin/chromium', '/usr/bin/chromium-browser'].find(p => fs.existsSync(p));
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
fs.mkdirSync('screenshots', { recursive: true });

const server = spawn('node', ['server.js', '--port', String(PORT)], { stdio: ['ignore', 'pipe', 'inherit'] });
server.stdout.on('data', d => process.stdout.write('[server] ' + d));
await sleep(1200);
const sim = (...a) => new Promise((res, rej) => { const p = spawn('node', ['scripts/simulate.js', ...a], { env: { ...process.env, PORT } }); p.on('exit', c => c === 0 ? res() : rej(new Error('sim ' + c))); });

const browser = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox', '--autoplay-policy=no-user-gesture-required'] });
const page = await browser.newPage({ viewport: { width: 1080, height: 1920 } });
const errors = []; page.on('pageerror', e => errors.push(e.message)); page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
await page.goto(`http://localhost:${PORT}/?reset=1`); await sleep(1500);
await page.screenshot({ path: 'screenshots/01_start_leer.png' });

// Kleine Geschenke über den Node-Simulator (WebSocket → Server → Spiel)
await sim('gift', 'Rose', '6', 'Lena'); await sim('gift', 'TikTok', '3', 'Max'); await sim('gift', 'Finger Heart', '2', 'Sophie');
await sim('follow', 'NeuerFan'); await sim('like', '300', 'Mia');
await sleep(2500);
await page.screenshot({ path: 'screenshots/02_kleine_geschenke.png' });

await sim('gift', 'Doughnut', '3', 'Jonas'); await sim('gift', 'Hand Hearts', '3', 'Emma'); await sim('gift', 'Confetti', '1', 'Paul');
await sim('chat', '!park', 'Hannah');
await sleep(1600);
await page.screenshot({ path: 'screenshots/03_mittlere_geschenke_konfetti.png' });
await sleep(1500);

await sim('gift', 'Galaxy', '1', 'Max');
await sleep(700);
await page.screenshot({ path: 'screenshots/04_galaxie_banner_bau.png' });
await sleep(3000);
await sim('gift', 'Lion', '1', 'Lena');
await sleep(1800);
await page.screenshot({ path: 'screenshots/05_loewe_stadion_feuerwerk_nacht.png' });

// Viel los: großer Mix
await sim('showcase'); await sim('random');
await sleep(9000);
await page.screenshot({ path: 'screenshots/06_grosse_stadt_nacht.png' });
await page.keyboard.press('n'); await sleep(3500);
await page.screenshot({ path: 'screenshots/07_grosse_stadt_tag.png' });

// Persistenz: neu laden → Stadt muss noch da sein
const before = await page.evaluate(() => window.tiktokStadt.state().buildings.length);
await page.reload(); await sleep(2000);
const after = await page.evaluate(() => window.tiktokStadt.state().buildings.length);
await page.screenshot({ path: 'screenshots/08_nach_reload.png' });
await page.keyboard.press('s'); await sleep(400);
await page.screenshot({ path: 'screenshots/09_test_panel.png' });
console.log(`Gebäude vor Reload: ${before}, nach Reload: ${after}`);
const snd = await page.evaluate(() => window.tiktokStadt.sound.debug());
console.log('Audio:', JSON.stringify(snd));
console.log(errors.length ? 'Browser-Fehler:\n' + errors.join('\n') : 'Keine Browser-Fehler ✅');
await browser.close(); server.kill();
process.exit(0);
